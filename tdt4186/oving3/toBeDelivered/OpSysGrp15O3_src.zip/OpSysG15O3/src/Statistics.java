/**
 * This class contains a lot of public variables that can be updated
 * by other classes during a simulation, to collect information about
 * the run.
 */
public class Statistics
{
	/** The number of processes that have exited the system */
	public long nofCompletedProcesses = 0;
	/** The number of processes that have entered the system */
	public long nofCreatedProcesses = 0;
	/** The total time that all completed processes have spent waiting for memory */
	public long totalTimeSpentWaitingForMemory = 0;
	/** The time-weighted length of the memory queue, divide this number by the total time to get average queue length */
	public long memoryQueueLengthTime = 0;
	/** The largest memory queue length that has occured */
	public long memoryQueueLargestLength = 0;
    
	public long forcedSwitches = 0;
	public long ioOps = 0;
	public long cpuTime = 0;
	public long maxCpuQueue = 0;
	public long maxIoQueue = 0;
	public long processedProc = 0;
	public long placedInCpuQueue = 0;
	public long placedInIo = 0;
	public long totalTimeCpuQueue = 0;
	public long totalTimeIoQueue = 0;
	public long totalTimeIO = 0;
	
	
	/**
	 * Prints out a report summarizing all collected data about the simulation.
	 * @param simulationLength	The number of milliseconds that the simulation covered.
	 */
	public void printReport(long simulationLength) {
		System.out.println();
		System.out.println("Simulation statistics:");
		System.out.println();
		System.out.println("Number of completed processes:                              "
				+nofCompletedProcesses);
		System.out.println("Number of created processes:                                "
				+nofCreatedProcesses);
		System.out.println("Number of forced Process switches:                          "
				+forcedSwitches);
		System.out.println("IO Operations:                                              "
				+ioOps);
		System.out.println("Throughput: (finished/sec)                                  "
				+((float)nofCompletedProcesses/(float)(simulationLength/1000)));
		System.out.println();
		
		
		System.out.println("Active CPUtime:                                             "
				+cpuTime);
		System.out.println("Inactive CPUtime:                                           "
				+(simulationLength-cpuTime));
		System.out.println("Active CPU percentage:                                      "
				+(float)((cpuTime/(float)simulationLength)*100));
		System.out.println("Inactive CPU percentage:                                    "
				+(float)(100-((cpuTime/(float)simulationLength)*100)));
		System.out.println();
		System.out.println("Largest occuring memory queue length:                       "
				+memoryQueueLargestLength);
		System.out.println("Average memory queue length:                                "
				+(float)memoryQueueLengthTime/simulationLength);
		System.out.println("Largest occuring CPU queue length:                          "
				+maxCpuQueue);
		//TODO:
		//System.out.println("Average CPU queue length:									"+"huh?");
		System.out.println("Largest occuring IO queue length:                           "
				+maxIoQueue);
		//TODO:
		//System.out.println("Average IO queue length:									"+"huh?");
		System.out.println();
		if(nofCompletedProcesses > 0) {
			System.out.println("Average # of times a process has been placed in memory queue:  "+1);
			System.out.println("Average time spent waiting for memory per process:             "+
				totalTimeSpentWaitingForMemory/nofCompletedProcesses+" ms");
			System.out.println("Average # of times a process has been placed in CPU queue:     "
					+(placedInCpuQueue/processedProc));
			System.out.println("Average time spent waiting for CPU per process:                "
					+totalTimeCpuQueue/nofCompletedProcesses+" ms");
			System.out.println("Average # of times a process has been placed in IO queue:      "
					+(placedInIo/processedProc));
			System.out.println("Average time spent waiting for IO:                             "
					+totalTimeIoQueue/nofCompletedProcesses+" ms");
			System.out.println();
			System.out.println("Time per completed process:                                 "
					+(float)simulationLength/nofCompletedProcesses+" ms");
			System.out.println("Time per completed process waiting for memory:              "
					+(float)totalTimeSpentWaitingForMemory/nofCompletedProcesses+" ms");
			System.out.println("Time in CPU per completed process:                          "
					+(float)cpuTime/nofCompletedProcesses+" ms");
			System.out.println("Time per completed process waiting for CPU:                 "
					+(float)totalTimeCpuQueue/nofCompletedProcesses+" ms");
			System.out.println("Time per completed process waiting for IO:                  "
					+(float)totalTimeIoQueue/nofCompletedProcesses+" ms");
			System.out.println("Time in Io per completed process:                           "
					+(float)totalTimeIO/nofCompletedProcesses+" ms");
		}
		
	}
}
