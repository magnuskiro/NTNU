package no.ntnu.idi.dm.arm.apriori;

import java.util.List;

public class BruteForceApriori<V> extends BaseApriori<V> {

	public BruteForceApriori(List<ItemSet<V>> transactions) {
		super(transactions);
	}

	@Override
	public void apriori(Double minSupport) {
		// TODO
	}

}
