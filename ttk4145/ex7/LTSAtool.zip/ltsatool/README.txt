INSTALLATION INSTRUCTIONS

You must first install a Java (TM) 2 run time system v1.5.0 or later.

Then, you can start using the LTSA tool immediately simply by double clicking on the ltsa.jar file, either on Windows or MAC OS.


WINDOWS

To install a desktop shortcut icon, run the create_shortcut.vbs script by double clicking on it.

To install a file association for .lts files, run the create_file_assoc.vbs script by double clicking on it.

MAC

Icons to be done!