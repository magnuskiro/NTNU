/*****************************************************************************
 * 
 * Øving 2 UCSysDes
 *
 * Headerfil
 *
 *****************************************************************************/

#ifndef OEVING_2_H 		/* vanlig måte å unngå headerrekursjon på */
#define OEVING_2_H
#include <avr32/ap7000.h> 	/* inkludere Atmel-headerfil */
#include <stdio.h> 	  	/* includes system-header file */
#include <sys/interrupts.h>	/* includes interrupts header file */
#include "sinetable.h"

/* legg andre "includes" her, sammen med "defines" og prototyper */

/* defines variables */

//declares pointers to registers 
volatile avr32_dac_t *dac = &AVR32_DAC;
volatile avr32_pio_t *piob = &AVR32_PIOB;
volatile avr32_pio_t *pioc = &AVR32_PIOC;
volatile avr32_sm_t *sm = &AVR32_SM;

//Buttons.
const volatile sw0 = 0xfe;
const volatile sw1 = 0xfd;
const volatile sw2 = 0xfb;
const volatile sw3 = 0xf7;
const volatile sw4 = 0xef;
const volatile sw5 = 0xdf;
const volatile sw6 = 0xbf;
const volatile sw7 = 0x7f;

//songs
//starwars
const int song1l[15] = {24000, 46000, 46000, 16000, 16000, 46000, 46000, 46000, 16000, 16000, 16000, 16000, 16000, 20000, 46000};
const short song1f[15] = {262*2, 349*2, 392*2, 415*2, 466*2, 415*2, 262*2, 349*2, 392*2, 415*2, 349*2, 415*2, 350*2, 349*3, 311*3};
//loose song
const int song2l[14] = {6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 20000};
const short song2f[14] = {370*3, 349*3, 330*3, 311*3, 294*3, 277*3, 262*3, 494*2, 466*2, 440*2, 415*2, 392*2, 370*2, 349*2}; 
//win song
const int song3l[5] = {6500, 6000, 6000, 6000, 25000};
const short song3f[5] = {262*3, 294*3, 330*3, 349*3, 392*3};
//song
const int song4l[7] = {8000,10000,8000,6000,7000,10000};
const short song4f[7] = {494, 440, 370, 370, 294*2, 262*2};

/*tone map, used in songs. 
H = 494,
AISS = 466,
A = 440,
GISS = 415,
G = 392,
FISS = 370,
F = 349,
E = 330,
DISS = 311,
D = 294,
CISS = 277,
C = 262,
*/

/* prototyper */
__int_handler *int_handler (void);
void set_interupt_base (void *base);
__int_handler register_int(__int_handler handler, int int_grp, int line, int priority);
void init_interupt (void);
void push_button(void);
void register_interrupts(void);
void play(short a);
void initHardware (void);
int main (int argc, char *argv[]);
inline void getSinesample(void);
void getSquareSample(void);
void loop(void);
void next_note();
void nullify(void);

#endif
