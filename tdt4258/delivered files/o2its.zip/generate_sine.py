from math import sin, pi

quart = 32
half = quart*2
tablesize = half*2

h = open("sinetable.h", "w")
h.write("""#ifndef sinetable_h 		/* to avoid header recursion */
#define sinetable_h
const short sinetable[%d] = {
""" % (tablesize))

amplitude = 100  #max = 32760
quart_period = [0]*quart
for i in range(quart):
	quart_period[i] = amplitude*(sin(pi/half*i))

#for i in quart_period:
#	print i


full_period = []
for i in quart_period:
	full_period.append(i)
for i in range(quart,quart*2):
	full_period.append(quart_period[(quart*2-1)-i])
for i in quart_period:
	full_period.append(-i)
for i in range(quart,quart*2):
	full_period.append(-quart_period[(quart*2-1)-i])

#for i in full_period:
#	print int(i)

for i in range(tablesize):
	if i%8 == 0:
		h.write("\n")
	if i < tablesize-1:	
		h.write("%d,\t" % int(full_period[i]))
	else:
		h.write("%d\n\n" % int(full_period[i]))
h.write("};\n#endif")
h.close()
