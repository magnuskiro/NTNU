/*****************************************************************************
 * 
 * Øving 2 UCSysDes
 *
 *****************************************************************************/

#include "oeving2.h"

/* start variables */
int led = 0x01;
short plays = 1;
int square = 0; 
int bitrate = 46875;
short amp = 4000;
short temp_amp = 4000;
int sample;

//square wave variables
short square_sample_ready = 1;
int count = 0;
int square_wave = 1;
short square_freq;
short time = 0;
int square_x = 340850;
int song_pos = 0;
int teller = 0;
short no_samples;
short counter = 0;
int duration = 0;
int wave_length = 53;

//sine wave variables
int sine_sample_ready = 0;
int sine_sample_count = 0; //counts how many samples have been output to the DAC
int sine_sample_no = 0; //x-position to calculate sine value
int sine_track_count = 0; //keeps track of where we are in the audio track
int sine_note;
int sine_wave = 1;
int sine_freq; //frequency of note to be played
int sine_length; //duration of note
int sine_x; //
int den;
int a;
int delta;
int *song_length_pointer;// = &song1l[0];
short *song_freq_pointer;// = &song1f[0];

/* end variables. */

__int_handler *dac_int_handler ()
{
	dac->SDR.channel0 = (short)sample;
	dac->SDR.channel1 = (short)sample;
	square_sample_ready = 0;
	sine_sample_ready = 0;
	return (void*)0;
}

__int_handler *button_int_handler ()
{
	int clear = piob->isr;	
	push_button();
	clear = piob->isr;	
	return (void*)0;
	
}

/* main kalles når programmet starter */
int main (int argc, char *argv[])
{
	register_interrupts();
	initHardware();
	while (1){
		if(square){
			getSquareSample();
		}
		else{
			getSineSample();
		}
	}
	return 0;
}

void push_button()
{
	int pushed = piob->pdsr;
	if ((pushed & 0xff) == sw0) { //paddle hit 
		square = 1; 
		square_freq = 0;
		duration = 0;
		amp = 4000;
		wave_length = 220;
		time = 2000;
	} 
	else if ((pushed & 0xff) == sw1) {//hit wall
		square = 1; 
		square_freq = 0;
		duration = 0;
		amp = 4000;
		wave_length = 53;
		time = 2000;
	} 
	else if ((pushed & 0xff) == sw2) { //loose life 
		square = 1; 
		square_freq = 0;		
		duration = 0;
		amp = 4000;
		wave_length = 400;
		time = 14000;
	} 
	else if((pushed & 0xff) == sw3) {  // play win song
		amp = temp_amp;
		square = 0; 
		song_length_pointer = &song3l[0];
		song_freq_pointer = &song3f[0];
		nullify();
		next_note();
	} 
	else if((pushed & 0xff) == sw4) { //play loose song
		amp = temp_amp;
		square = 0;
		song_length_pointer = &song2l[0];
		song_freq_pointer = &song2f[0];
		nullify();
		next_note();
	} 
	else if((pushed & 0xff) == sw5) {//play starwars
		amp = temp_amp;
		square = 0;
		song_length_pointer = &song1l[0];
		song_freq_pointer = &song1f[0];
		nullify();
		next_note();
	} 
	else if((pushed & 0xff) == sw6) {//volume down
		if(amp >= 4000){//negative apm is useless. 
			amp -= 4000;
			temp_amp -= 4000;
			led = (led >> 1)& 0x7f;
		}
		pioc->codr = 255; 
		pioc->sodr = led;
} 
	else if((pushed & 0xff) == sw7) { //volume up
		if(amp<=28000){
			amp += 4000;
			temp_amp += 4000; 
			led = (led << 1)|1;
		}
		pioc->codr = 255;
		pioc->sodr = led;
	}
}

//sine
inline void getSineSample() 
{
	if(sine_sample_ready) return;
	if(sine_sample_no == sine_length) sine_sample_no = 0;
	if(sine_sample_count < sine_note) 
	{
		a = sine_sample_no*sine_x;
		delta = a/1000;
		delta = a-(delta*1000);
		a = a/1000;
		sample = sinetable[a]*1000+((sinetable[a+1]*1000-sinetable[a]*1000)*delta/1000);
		sample = (sample/1000)*(amp/100);
		sine_sample_ready = 1;
		sine_sample_no++;
		sine_sample_count++;
	}
	if(sine_sample_count == sine_note) 
	{
		sine_sample_count = 0;
		next_note();
	}
}

//resets the song counters, so the next song starts at the beginning.
void nullify()
{
	sine_sample_count = 0;
	sine_track_count = 0;
	sine_sample_no = 0;
	sine_sample_ready = 1;
}

//sets the next note in  a sine song.
void next_note()
{
	sine_note = song_length_pointer[sine_track_count];
	sine_freq = song_freq_pointer[sine_track_count];
	sine_track_count++;
	sine_length = bitrate/sine_freq;
	sine_x = 128000/sine_length;
}

//square
void getSquareSample()
{
	if (square_sample_ready) return;
	if (duration <= time) {
		if(square_freq == wave_length) {
			square_wave = square_wave*-1;
			square_freq = 0;
		}
		square_freq++;
		duration++;
	}
	if (duration == time*2) {
 		 amp = 0;
	}
	if (duration>time) {
		if(square_freq == wave_length/2) {
			square_wave = square_wave*-1;
			square_freq = 0;
		}
		square_freq++;
		duration++;
	}
	square_sample_ready = 1;
	sample = amp*square_wave;
}

void register_interrupts()
{
	set_interrupts_base ((void *)AVR32_INTC_ADDRESS);
	register_interrupt ((__int_handler)(button_int_handler), AVR32_PIOB_IRQ/32, AVR32_PIOB_IRQ%32, INT0);
	register_interrupt ((__int_handler)(dac_int_handler), AVR32_DAC_IRQ/32, AVR32_DAC_IRQ%32, INT1);
	init_interrupts();
}

/* funksjon for å initialisere maskinvaren, må utvides */
void initHardware () 
{
	//led setup
	pioc->per = 255;
	pioc->oer = 255;
	pioc->codr = 0;
	pioc->sodr = led;
	
	//button setup
	piob->per = 255;
	piob->puer = 255;
	piob->idr = 0;
	piob->ier = 255;
	
	//dac interupt setup. 
	piob->PDR.p20 = 1;
	piob->PDR.p21 = 1;
	piob->ASR.p20 = 1;
	piob->ASR.p21 = 1;
	
	//dac clock setup
 	avr32_sm_pm_gcctrl_t * clock_ctrl = (avr32_sm_pm_gcctrl_t *)&sm->pm_gcctrl[6];
 	clock_ctrl->oscsel = 1;
 	clock_ctrl->diven = 1;
	clock_ctrl->div = 0;
	clock_ctrl->cen = 1;
	//dac activation
	dac->CR.en = 1;
	dac->IER.tx_ready = 1;
	
}