#ifndef OBJECTS_H
#define OBJECTS_H

#include "pong.h"

typedef struct object_struct
{
	int pos_x;
	int pos_y;
	int width;
	int height;
	int size;
} object;

typedef struct game_data_struct 
{
	int running;
	int speed;
	int speed_x;
	int speed_y;
	int bounce_count;
	int x_a;
	int y_a;
	int p1_points;
	int p2_points;
} game_data;

object player1;
object player2;
object ball;
game_data game;

#endif
