#ifndef MAIN_H
#define MAIN_H

char *speedupLED;

// Prototypes
void init_BLdriver();
void exit_BLdriver();
void init_game();
void * readButtons();
void initiate_objects();
void initiate_game();
void setled();

#endif
