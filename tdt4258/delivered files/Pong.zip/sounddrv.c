#include "sounddrv.h"
#include <stdio.h>
#include <stdlib.h>
#include <linux/soundcard.h>
#include <fcntl.h>

//sound struct. holding the samples and the length of the sound.
typedef struct{
	unsigned int length;
	char *song;
} sound;

//the sound list that holds all the sound when running.
sound soundList[numberOfSounds];

// all the filenames of different songs.
//char * soundNames[numberOfSounds] = {"hit_paddel.WAV", "hit_wall.WAV", "loose_game.WAV", "loose_point.WAV"};
char * soundNames[numberOfSounds] = {"paddle_hit1.wav", "wall_hit1.wav", "win1.wav", "score1.wav"};

//sound driver. /dev/dsp
int dev_s;
int dsp_rate = 44100;

// sound setup
void init_sounddrv()
{
	currentSound == -1;
	//opening the sound driver. Prints error if it fails.
	if((dev_s = open("/dev/dsp", O_RDWR)) == -1)
	{
		printf("[ERROR] Error opening SOUND driver /dev/dsp.\n");
		exit(1);
	}

	// reads all the sounds and puts them in memory.
	// as the sounds are smal and frequantly used this is an efficient thing to do.
	int i = 0;
	for(i = 0; i < numberOfSounds; i++){
		char *c = malloc(100*sizeof(char));
		sprintf(c, "sounds/%s", soundNames[i]);
		FILE *file = fopen(c, "rb");
		long longFileSize;
		size_t result;
		
		// if opening the file did not work we catch the error here.
		if (file==NULL) { 
			printf("[ERROR] Cannot read %s", soundNames[i]);
			exit(0);
		}
		
		fseek (file , 0 , SEEK_END); //finds end of file. 
		longFileSize = ftell (file); //stores the size of the file. 
		rewind (file); //goes back to the beginning of the file.
		
		// allocating memory to contain our sound file.
		soundList[i].song = (char*) malloc (sizeof(char)*longFileSize);
		soundList[i].length = longFileSize; // set the length of sound.
		if (soundList[i].song == NULL) { // checks if the sound has been loaded.
			printf("[ERROR] Memory error"); 
			exit (2);
		}
		result = fread (soundList[i].song,1,longFileSize,file);
		
		// cleanup after reading file.
		free(c);
		fclose (file);
	}
}

void *play(){

	//while no sound is choosen we wait for it to be set.
	while(currentSound == -1){
		usleep(1);
	}

	int i = 0;
	//plays the current sound.
	for(i = 0; i < soundList[currentSound].length; i++){
		//writes a wav sample to the sound device. 
		write(dev_s, &soundList[currentSound].song[i], 1);
	}
	//clears sound selection after playing the sound.
	currentSound = -1; 
}

void exit_sounddrv(){
	currentSound = -1;
	//closing the sound device. 
	if(close(dev_s)){
		printf("[ERROR] Cannot close /dev/dsp.\n");
	}

	int i = 0;
	//clearing memory when closing the sound device. 
	for(i = 0; i < numberOfSounds; i++){
		free(soundList[i].song);
	}
}
