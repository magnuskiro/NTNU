/*****************************************************************************
 *
 * Exercise 3 uCSysDes, driver code
 *
 *****************************************************************************/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/ioport.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include "ap7000.h"

#define dev_name "blmjp"

/* variables */
int dev_major = 0;
int dev_minor = 0;
int nr_devs = 1;
//int region_length = 1024;

/* LEDs & buttons pointers */
volatile avr32_pio_t *piob = &AVR32_PIOB;

/* prototypes */
static int __init driver_init(void);
static void __exit driver_exit(void);
static int driver_open (struct inode *inode, struct file *filp);
static int driver_release (struct inode *inode, struct file *filp);
static int driver_read (struct file *filp, char __user *buff,
                     size_t count, loff_t *offp);
static int driver_write (struct file *filp, const char __user *buff,
                      size_t count, loff_t *offp);

/* fops-struct */
static struct file_operations driver_fops = {
  .owner = THIS_MODULE,
  .read = driver_read,
  .write = driver_write,
  .open = driver_open,
  .release = driver_release
};

//driver_dev->ops = &driver_fops;

/*****************************************************************************/
/* init-function (called when module is loaded) */

static int __init driver_init (void) {
	
	/* device driver struct see p.55 of LDD */
	dev_t driver_dev = 0;
	int result = 0;
  
	/* allocate device number */
  	// ref. p.45 LDD
  	result = alloc_chrdev_region(&driver_dev, dev_minor, nr_devs, dev_name);	
  
  	// ref p.48 LDD
  	if(result < 0) {				
		printk(KERN_INFO "Failed to assign major\n");
  		return result;
  	}

  /* ask for access to I/O ports */
  
	request_region(AVR32_PIOB_ADDRESS, 1024, dev_name);
  /* initialize PIO-hardware (as in exercise 2) */
  	
	//led setup
	piob->per = 0xff;
	piob->oer = 0xff;
	piob->codr = 0xff;
	piob->sodr = 0xff;
	
	//Sette opp knapper
	piob->puer = 0xff;
 
  /* register device in the system (must be done after everything else is initialized */
  	
	dev_major = register_chrdev(0, dev_name, &driver_fops);

	printk(KERN_INFO "Major: %d\t Minor:%d\n", dev_major, dev_minor);
	
  return 0;
}

/*****************************************************************************/
/* exit-function (called when the module is removed from the system) */

static void __exit driver_exit (void) {

	release_region(AVR32_PIOB_ADDRESS, 1024);
	
	//ref p.56 LDD
	unregister_chrdev(dev_major, dev_name);
	printk(KERN_INFO"Driver released");
}

/*****************************************************************************/
/* fops-functions */

static int driver_open (struct inode *inode, struct file *filp) {
  return 0;
}

/*---------------------------------------------------------------------------*/

static int driver_release (struct inode *inode, struct file *filp) {
  return 0;
}

/*---------------------------------------------------------------------------*/

static ssize_t driver_read (struct file *filp, char __user *buff,
              size_t count, loff_t *offp) {
		      
	int temp = (0x4001E700&(0xffffffff-piob->pdsr))>>8;
	if(temp>256){
		temp = ((0x7&temp)|((temp>>2)&0xFFFFFFF8))|(temp>>15);
	}else if(temp > 31){
		temp = (0x7&temp)|((temp>>2)&0xFFFFFFF8);
	}
	char buttons = temp;

	copy_to_user(buff,&buttons,1);
	return (buttons == 0x0)?-1:1;

}

/*---------------------------------------------------------------------------*/

static ssize_t driver_write (struct file *filp, const char __user *buff,
               size_t count, loff_t *offp) {
 	

	char read;

	copy_from_user(&read,buff,1);
	
	printk(KERN_INFO "Led value : %d \n", read);
	piob->codr = 0xff;
	piob->sodr = read;

  return count;
}

/*****************************************************************************/
/* module description macros */

module_init (driver_init);  								// indicates the init-function 
module_exit (driver_exit);  								// indicates the exit-function 

MODULE_LICENSE ("GPL");     								// license for the module 
MODULE_DESCRIPTION ("Driver for leds and buttons on Atmel STK1000 AT32AP7000");    	// textual description of the module 
MODULE_VERSION ("");       								// version number 
MODULE_AUTHOR ("Jan Alexander Stormark Bremnes, Magnus Kirø");         			// author(s) 

