#ifndef SOUNDDRV_H
#define SOUNDDRV_H

#define numberOfSounds 4

// the current song. the value corresponds with the sounds in the soundList.
// currentSound == -1 no sound is choosen, so we have silence.
int currentSound;

// Init and exit
void init_sounddrv();
void exit_sounddrv();

// play function to play sounds.
void *play();

#endif
