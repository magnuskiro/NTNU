#ifndef DRAW_SCORE_H
#define DRAW_SCORE_H 

void score1(int);
void score2(int);
void draw_score1(char[]);
void draw_score2(char[]);

#endif
