/******************************/
/*	 INCLUDES	      */	
/******************************/
#include <unistd.h> 
#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <stdlib.h>
#include "pong.h"
#include "objects.h"
#include "main.h"
#include "sounddrv.h"
#include "draw_score.h"

int location = 0, pLocation = 0;	//location of pixel being drawn & previous location
int amount = 1; // movement amount in pixels
int fbfd = 0;
char *fbp = 0;
int xDir = -1, yDir = 1;
int game_limit; // the number of goals before one player wins.
int speedcounter = 0;
	
void init_pong()
{
	init_screen();
	create_sprites();
	draw_screen();		// starting screen
	game_limit = 5;
	game.speed = 1;
	speedcounter = 0;
	xDir = -1;
	yDir = 1;
	*speedupLED = 1;
}

void *pong()
{
	while(game.running == 1) 
	{
		if(game.p1_points == game_limit || game.p2_points == game_limit)
		{
			game.running = 0;
			currentSound = 2;
			play();
			break;
		}
		move_ball();
		score1(game.p1_points);
		score2(game.p2_points);
		draw_screen();
		if(speedcounter == 500){
			yDir = yDir*game.speed;
			xDir = xDir*game.speed;
			game.speed++;
			speedcounter = 0;
			setled();
		}
			
	}	
	close(fbfd);
	return;
}

void init_screen() 
{
	/* Open the file for reading and writing */
	fbfd = open("/dev/fb0", O_RDWR);
	if (!fbfd) {
		printf("Error: cannot open framebuffer device\n");
	}
	printf("The framebuffer device was opened successfully\n");

	/* Map the device to memory */
	fbp = (char *)mmap(0, SCREEN_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fbfd, 0);
	if ((int)fbp == -1) {
		printf("Error: failed to map framebuffer device to memory\n");
	}
	printf("The framebuffer device was successfully mapped to memory\n");	
}

void create_sprites() 
{
	int p = 0, i = 0, j = 0, x = 0, y = 0;
	
	/* Creates left paddle */
	printf("Loading left paddle in buffer\n");
	for(i = P1_X; i < P1_W + P1_X; i++) {
		for(j = P1_Y; j < P1_H + P1_Y; j++) {
			x = i;
			y = j;
			location = (x * X_OFFSET) + (y * Y_OFFSET);		/* Figure out where in memory to put the pixel */
			P1[p] = location;
			p++;
		}
	}
	printf("Done creating Player 1\n");	
	p = 0, i = 0, j = 0, x = 0, y = 0;
	/* Creates right paddle */
	printf("Loading right paddle in buffer\n%d\n", P2_X);
	for(i = P2_X; i < P2_W + P2_X; i++) {
		for(j = P2_Y; j < P2_H + P2_Y; j++) {
			x = i;
			y = j;
			location = (x * X_OFFSET) + (y * Y_OFFSET);		/* Figure out where in memory to put the pixel */
			P2[p] = location;
			p++;
		}
	}
	printf("Done creating Player 2\nsize: %d\n", p);
	p = 0, i = 0, j = 0, x = 0, y = 0;
	/* Creates ball */
	printf("Loading ball in buffer\n");
	for(i = BALL_X; i < BALL_W + BALL_X; i++) {
		for(j = BALL_Y; j < BALL_H + BALL_Y; j++) {
			x = i;
			y = j;
			location = (x * X_OFFSET) + (y * Y_OFFSET);
			BALL[p] = location;
			p++;
		}
	}
	printf("Done creating ball\n");
}
	
/* Moves the paddles by creating a duplicate, writing zero to the duplicate, and moves the original */	
void move_paddle(int player, int direction)
{
	int i;
	if ((player1.pos_y + amount*direction) <= 0 || (player1.pos_y + amount*direction + P1_H) >=SCREEN_HEIGHT) return;
	if ((player2.pos_y + amount*direction) <= 0 || (player2.pos_y + amount*direction + P2_H) >=SCREEN_HEIGHT) return;
	if (player == 1) { // change direction so the paddle  moves up/doown not right/left.
		for(i = 0; i < PADDLE_SIZE; i++) {
			PREV_P1[i] = P1[i];
			P1[i] = P1[i] + (amount * direction * Y_OFFSET);
			pLocation = PREV_P1[i];
			location = P1[i];
			buffer[pLocation+1] = 0;
			buffer[pLocation+2] = 0;
			buffer[pLocation+3] = 0;
			buffer[location+1] = 200;
			buffer[location+2] = 0;
			buffer[location+3] = 255;
		}
		player1.pos_y += (amount*direction);
	} else {
		for(i = 0; i < PADDLE_SIZE; i++) {
			PREV_P2[i] = P2[i];
			P2[i] = P2[i] + (amount * direction * Y_OFFSET);
			pLocation = PREV_P2[i];
			location = P2[i];
			buffer[pLocation+1] = 0;
			buffer[pLocation+2] = 0;
			buffer[pLocation+3] = 0;
			buffer[location+1] = 0;
			buffer[location+2] = 200;
			buffer[location+3] = 255;
		}
		player2.pos_y += (amount*direction);
	}
}

void delay(int amount)
{
	int i;
	for(i = 0; i < amount; i++) {}
}

void move_ball()
{
	speedcounter++;
	if(ball.pos_y + yDir + game.y_a < 0 || ball.pos_y + yDir + game.y_a > SCREEN_HEIGHT) 
	{ 
		yDir *= -1;
	}
	ball.pos_x += (xDir*game.x_a);
	ball.pos_y += (yDir*game.y_a);
	//printf("Balls position: %d \t %d\n", ball.pos_x, ball.pos_y);
	// see if the ball is in an ilegal space = point to player
	if(ball.pos_x <= 0)  //out on the left side
	{
		if(ball.pos_y + BALL_H >= player1.pos_y && ball.pos_y <= player1.pos_y + P1_H && ball.pos_x <= 5)//ball is inside paddle
		{
			xDir = xDir*-1; // left paddle
			currentSound = 0; // set spund in sounddrv
			play(); // play sound
			return;
		}
		else 
		{
			game.p2_points++;	// score left
			game.speed = 1;
			currentSound = 3; //set sound in sounddrv
			play(); // play sound in sounddrv
			reset();
			return;
		}
	}
	else if(ball.pos_x + 4 >= SCREEN_WIDTH-5)// out on the right side
	{
		if(ball.pos_y + BALL_H >= player2.pos_y && ball.pos_y <= player2.pos_y + P2_H && ball.pos_x+4 >= player2.pos_x)//ball is inside paddle
		{
			xDir = xDir*-1; // right paddle
			currentSound = 0; // set spund in sounddrv
			play(); // play sound
			//randomtall();
			return;
		}
		else // reset and pint to oter player
		{
			game.p1_points++;	// score right
			game.speed = 1;
			currentSound = 3; //set sound in sounddrv
			play();// play sound in sounddrv
			reset();
			return;
		}
	}
	// wall bounce
	else if (ball.pos_y <= 0) 
	{
		yDir = yDir*-1; // upper wall
		currentSound = 1; //set sound in sounddrv
		play();// play sound in sounddrv
		return;
	} 
	else if (ball.pos_y + 4 >= SCREEN_HEIGHT)
	{
		yDir = yDir*-1; 	// lower wall
		currentSound = 1; //set sound in sounddrv
		play();// play sound in sounddrv
		return;
	} 
	repaint_ball(xDir, yDir);
}

void repaint_ball(int xDir, int yDir)
{
	int i;
	int amount = ((xDir*game.x_a) * X_OFFSET) + ((yDir*game.y_a) * Y_OFFSET);
	for(i = 0; i < BALL_SIZE; i++) {
		PREV_BALL[i] = BALL[i];
		BALL[i] = BALL[i] + amount;
		pLocation = PREV_BALL[i];
		location = BALL[i];
		buffer[pLocation+1] = 0;
		buffer[pLocation+2] = 0;
		buffer[pLocation+3] = 0;
		buffer[location+1] = 200;
		buffer[location+2] = 0;
		buffer[location+3] = 255;
	}
}

void reset() 
{
	printf("POINT SCORED!\t %d\n", game.p2_points);
	clear_screen();
	delay(5000000);
	initiate_objects();
	init_pong();
}

void *draw_screen()
{
	/* Draws the paddles and ball on screen */
	int i = 0, l = 0, r = 0, b = 0, middle = 159;
	
	for(i = 0; i < SCREEN_HEIGHT; i++) {
		location = (middle * X_OFFSET) + (i * Y_OFFSET);
		buffer[location + 1] = 255;
		buffer[location + 2] = 0;
		buffer[location + 3] = 0;
	}
	for (i = 0; i < PADDLE_SIZE; i++) {
		l = P1[i];
		r = P2[i];
		/* left paddle */
		buffer[l+1] = 200; //BLUE
		buffer[l+2] = 0;   //GREEN	
		buffer[l+3] = 255; //RED
		/* right paddle */
		buffer[r+1] = 0; //BLUE
		buffer[r+2] = 200;//GREEN	
		buffer[r+3] = 255;//RED
	}
	for(i = 0; i < BALL_SIZE; i++) {
		b = BALL[i];
		buffer[b+1] = 0; //BLUE
		buffer[b+2] = 255; //GREEN	
		buffer[b+3] = 0; //RED
	}
	memcpy(fbp, buffer, SCREEN_SIZE);
}

void clear_screen() 
{
	int i;
	for (i = 0; i < SCREEN_SIZE; i++) {
		buffer[i] = 0;
	}
}
