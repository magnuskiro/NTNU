#/bin/bash
echo "removing directories"
rm -r /home/pong
rmmod blmjp
rm -r /dev/blmjp
echo "BLdriver SETUP"
wget http://folk.ntnu.no/kiro/miccon/blmjp.ko
insmod blmjp.ko
echo "Insert Major:"
read major
echo "Insert Minor:"
read minor 
mknod /dev/blmjp c $major $minor
#rm blmjp.ko
echo "driver SETUP COMPLETE"
echo "Creating directories"
mkdir /home/pong
mkdir /home/pong/sounds 
cd /home/pong
echo "getting the game"
wget http://folk.ntnu.no/kiro/miccon/mjp
chmod 777 *
cd /home/pong/sounds
echo "getting sounds"
#wget http://folk.ntnu.no/kiro/miccon/sounds/hit_paddel.WAV
#wget http://folk.ntnu.no/kiro/miccon/sounds/hit_wall.WAV
#wget http://folk.ntnu.no/kiro/miccon/sounds/loose_game.WAV
#wget http://folk.ntnu.no/kiro/miccon/sounds/loose_point.WAV

wget http://folk.ntnu.no/kiro/miccon/sounds/paddle_hit1.wav
wget http://folk.ntnu.no/kiro/miccon/sounds/wall_hit1.wav
wget http://folk.ntnu.no/kiro/miccon/sounds/win1.wav
wget http://folk.ntnu.no/kiro/miccon/sounds/score1.wav
chmod 777 *
cd /home/pong
echo "done"