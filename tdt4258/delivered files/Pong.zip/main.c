#include "sounddrv.h"
#include "objects.h"
#include "pong.h"
#include "main.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h>
#include <math.h>

#define dev "/dev/blmjp"

int driv;//buttons and leds
int buttonSleep; // sleep interval for the buton thread.
int started;
int running;

void init_BLdriver()
{
	// button and leds driver initialisation. 
	if((driv = open(dev, O_RDWR)) == -1)
	{
   		printf("Cannot open /dev/BLdriver.\n");
   	 	exit(1);
  	}
}

void exit_BLdriver()
{
	// turn off leds
	*speedupLED = 0;	
	write(driv, speedupLED, 1);

	// close button and led driver
	int ret = close(driv);
	if (ret == -1)
		printf("Failed to close BLdriver\n");
}

void * readButtons(){
	ssize_t readBytes;
	char * c = malloc(sizeof(char));
	while(1){
		usleep(buttonSleep);
		readBytes = read(driv, c, 1);
		if ( readBytes == -1 )
		{
			continue;
		}

		// SW7
		if(*c&0x80){
			// amount, player, direction
			move_paddle(1, -1);
		}
		// SW6
		if(*c&0x40){ 
			// amount, player, direction
			move_paddle(1, 1);
		}
/*		// SW5
		if(*c&0x20){
		}
		// SW4
		if(*c&0x10){
		}
		// SW3
		if(*c&0x8){
		}
		// SW2
		if(*c&0x4){
		}
*/		// SW1
		if(*c&0x2){
			// amount, player, direction
			move_paddle(0, 1);
		}
		// SW0
		if(*c&0x1){
			// amount, player, direction
			move_paddle(0, -1);
		}	
	}
}

void setled()
{
	*speedupLED = *speedupLED|*speedupLED<<1;
	write(driv, speedupLED,1);

}

int main()
{
	// initiation
	init_BLdriver();
	init_sounddrv();
	initiate_objects();
	initiate_game();
	

	buttonSleep = 4000;	

	speedupLED = malloc(sizeof(char));

 	*speedupLED = 1;
 	write(driv, *speedupLED,1);

	init_pong();

	pthread_t buttons;
	int buttonthread = pthread_create(&buttons, NULL, &readButtons, NULL);

	sleep(1);

	pong();

	exit_sounddrv();
	exit_BLdriver();

	return 0;
}

void initiate_objects() 
{
	/* Left paddle */
	player1.pos_x = P1_X;
	player1.pos_y = P1_Y;
	player1.height = P1_H;
	player1.width = P1_W;
	player1.size = PADDLE_SIZE;
	
	/* Right paddle */
	player2.pos_x = P2_X;
	player2.pos_y = P2_Y;
	player2.height = P2_H;
	player2.width = P2_W;
	player2.size = PADDLE_SIZE;
	
	/* Ball */
	ball.pos_x = BALL_X;
	ball.pos_y = BALL_Y;
	ball.height = BALL_H;
	ball.width = BALL_W;
	ball.size = BALL_SIZE;
	
}

void initiate_game()
{
	
	/* Game data */
	game.running = 1;
	game.speed = 1;
	game.speed_x = -1;
	game.speed_y = 1;
	game.x_a = 1;
	game.y_a = 1;
	game.p1_points = 0;
	game.p2_points = 0;

}
