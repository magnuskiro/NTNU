#ifndef PONG_H
#define PONG_H

/******************************/
/*	 DEFINES 	      */	
/******************************/
// Screen
#define SCREEN_HEIGHT 239	// height of screen in pixels
#define SCREEN_WIDTH 319	// width of screen in pixels
#define SCREEN_SIZE 320*240*4	// size of screen byte-array

// Width, height, size and starting x and y coordinates of the ball
#define BALL_W 8
#define BALL_H 8
#define BALL_X (SCREEN_WIDTH / 2) - BALL_W / 2
#define BALL_Y (SCREEN_HEIGHT / 2) - BALL_H / 2
#define BALL_SIZE BALL_W * BALL_H

// Width, height, size and starting x and y coordinates of player 1's paddle
//player one is tho the left
#define P1_W 5
#define P1_H 50
#define P1_X 0
#define P1_Y (SCREEN_HEIGHT / 2) - (P1_H / 2)

// Width, height and starting x and y coordinates of player 2's paddle
// p2 is at the right
#define P2_W 5
#define P2_H 50
#define P2_X SCREEN_WIDTH - P2_W
#define P2_Y (SCREEN_HEIGHT / 2) - (P2_H / 2)

// Offsets (to get correct pixel)
#define X_OFFSET 4
#define Y_OFFSET 1280

// Directions for movement of ball
#define B_LEFT_DOWN 0
#define B_LEFT_UP 1
#define B_RIGHT_DOWN 2
#define B_RIGHT_UP 3

// Directions for paddle movement
#define UP -1
#define DOWN 1

#define PADDLE_SIZE P1_W * P1_H

#define SCORE1_X (SCREEN_WIDTH / 4) - 6 
#define SCORE1_Y (SCREEN_HEIGHT / 2) -12
#define SCORE2_X SCREEN_WIDTH - (SCREEN_WIDTH / 4) - 6
#define SCORE2_Y (SCREEN_HEIGHT / 2) -12

/******************************/
/*	 PROTOTYPES 	      */	
/******************************/
void * pong(void);
void init_screen(void);
void create_sprites(void);
void * draw_screen(void);

void move_paddle(int ,int);
void move_ball(void);

void delay(int);
void reset(void);
void clear_screen(void);

void wall_hit(void);
void paddle_hit(void);

void set_vectors(void);
void change_slope(void);
void check_direction(void); 
void repaint_ball(int xDir, int yDir);


/******************************/
/*	 VARIABLES 	      */	
/******************************/
int P1[PADDLE_SIZE]; 		// size of left paddle in x*y pixels
int P2[PADDLE_SIZE]; 		// size of right paddle in x*y pixels
int PREV_P1[PADDLE_SIZE];  	// holds the previous left paddle when moving it 
int PREV_P2[PADDLE_SIZE];  	// holds the previous right paddle when moving it
int BALL[PADDLE_SIZE];    	// size of ball in x*y pixels
int PREV_BALL[PADDLE_SIZE];   	// holds the previous ball when moving it
char buffer[SCREEN_SIZE];
char cBuffer[SCREEN_SIZE];


/******************************/
/*	 STRUCTURES 	      */	
/******************************/
// moved to objects.h

#endif
